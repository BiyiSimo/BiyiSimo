Display filters as a vertical bar:

!["Vertical"](../../../assets/webparts/search-filters/layouts/vertical_layout.png){: .center}