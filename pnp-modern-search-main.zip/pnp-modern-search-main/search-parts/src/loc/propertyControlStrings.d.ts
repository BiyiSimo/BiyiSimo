declare interface IPropertyControlStrings {
  CollectionDataItemFieldRequiredLabel: string;
}

declare module 'PropertyControlStrings' {
  const strings: IPropertyControlStrings;
  export = strings;
}
