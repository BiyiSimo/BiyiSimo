interface ITemplateRendererState {   
}

export default ITemplateRendererState;