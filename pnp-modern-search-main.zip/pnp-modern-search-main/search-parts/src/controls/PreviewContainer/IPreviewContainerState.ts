interface IPreviewContainerState {
    showCallout: boolean;
    isLoading: boolean;
}

export default IPreviewContainerState;