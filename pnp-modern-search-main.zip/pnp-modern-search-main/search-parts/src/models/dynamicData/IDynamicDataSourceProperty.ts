interface IDynamicDataSourceProperty {
    key: string;
    text: string;
}

export default IDynamicDataSourceProperty;