export interface ISuggestionProviderConfiguration {
    name: string;
    key: string;
    enabled: boolean;
    description;
}