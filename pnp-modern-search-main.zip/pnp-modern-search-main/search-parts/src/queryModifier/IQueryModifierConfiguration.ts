export interface IQueryModifierConfiguration {
    name: string;
    key: string;
    enabled: boolean;
    description:string;
    endWhenSuccessfull:boolean;
}