**This solution includes only one `.sppkg` file:**
- `pnp-modern-search-parts-<version_number>.sppkg` (Mandatory).

> Extensions (i.e. custom web components, layouts, etc.) must be deployed separately. See [PnP Modern Search - Extensibility samples](https://github.com/microsoft-search/pnp-modern-search-extensibility-samples) for more information.

**Useful resources**

- [Official documentation](https://microsoft-search.github.io/pnp-modern-search/)

____
