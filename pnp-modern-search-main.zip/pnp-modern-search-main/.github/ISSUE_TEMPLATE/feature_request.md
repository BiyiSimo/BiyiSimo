---
name: Feature request
about: Suggest an idea for the modern search
title: ''
labels: ''
assignees: ''

---

Log requests as ideas in the discussion forum.
