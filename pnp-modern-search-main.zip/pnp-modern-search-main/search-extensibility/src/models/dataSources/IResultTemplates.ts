export interface IResultTemplates {
    [resultTemplateId: string]: {
        body: string;
        displayName: string;
    };
}