export enum SortFieldDirection {
    Ascending = 1,
    Descending= 2    
}